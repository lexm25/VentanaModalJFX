package gui.viewsandcontrollers.segundaventana;

public class SegundaVentanaController {

}
